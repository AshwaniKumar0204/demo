﻿(function () {
    "use strict";
    angular.module("app", ['angucomplete-alt', 'angularUtils.directives.dirPagination', 'ngRoute', 'shalotelli-angular-multiselect','summernote']);
}());